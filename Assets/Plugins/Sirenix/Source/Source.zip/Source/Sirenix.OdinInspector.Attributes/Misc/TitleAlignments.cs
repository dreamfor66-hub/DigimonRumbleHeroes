//-----------------------------------------------------------------------
// <copyright file="TitleAlignments.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    /// <summary>
    /// Title alignment enum used by various attributes.
    /// </summary>
    /// <seealso cref="TitleGroupAttribute"/>
    /// <seealso cref="TitleAttribute"/>
    public enum TitleAlignments
    {
        /// <summary>
        /// Title and subtitle left aligned.
        /// </summary>
        Left,

        /// <summary>
        /// Title and subtitle centered aligned.
        /// </summary>
        Centered,

        /// <summary>
        /// Title and subtitle right aligned.
        /// </summary>
        Right,

        /// <summary>
        /// Title on the left, subtitle on the right.
        /// </summary>
        Split,
    }
}
#endif