//-----------------------------------------------------------------------
// <copyright file="ISubGroupProviderAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Internal
{
    using System.Collections.Generic;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    public interface ISubGroupProviderAttribute
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        /// <returns>Not yet documented.</returns>
        IList<PropertyGroupAttribute> GetSubGroupAttributes();

        /// <summary>
        /// Not yet documented.
        /// </summary>
        /// <param name="attr">Not yet documented.</param>
        /// <returns>Not yet documented.</returns>
        string RepathMemberAttribute(PropertyGroupAttribute attr);
    }
}
#endif