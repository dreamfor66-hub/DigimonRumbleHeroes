//-----------------------------------------------------------------------
// <copyright file="DrawWithVisualElementsAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// Force Odin to draw this value as an IMGUI-embedded UI Toolkit Visual Element.
    /// </summary>
    public class DrawWithVisualElementsAttribute : Attribute
    {
        public bool DrawCollectionWithImGUI;
    }
}
#endif